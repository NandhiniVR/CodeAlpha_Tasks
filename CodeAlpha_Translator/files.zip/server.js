// server.js — LinguaFlow proxy using @vitalets/google-translate-api
// Free, unlimited, no API key needed.

const express = require('express');
const path = require('path');
const app = express();

app.use(express.json({ limit: '1mb' }));

// Serve static frontend files
const staticDir = path.resolve(__dirname);
app.use(express.static(staticDir));

app.get('/health', (req, res) => res.json({ ok: true }));

// Translation endpoint
app.post('/api/translate', async (req, res) => {
  const { text, from = 'auto', to = 'en' } = req.body;

  if (!text || !text.trim()) {
    return res.status(400).json({ error: 'No text provided' });
  }

  try {
    // Dynamic import because @vitalets/google-translate-api is ESM
    const { translate } = await import('@vitalets/google-translate-api');

    const result = await translate(text, { from, to });

    res.json({
      translated: result.text,
      detected:   result.raw?.src || null,
    });
  } catch (err) {
    console.error('Translation error:', err.message);

    // Handle TooManyRequestsError gracefully
    if (err.name === 'TooManyRequestsError') {
      return res.status(429).json({ error: 'Too many requests. Please wait a moment and try again.' });
    }

    res.status(500).json({ error: err.message || 'Translation failed' });
  }
});

// Romanization endpoint
app.post('/api/romanize', async (req, res) => {
  const { text, from = 'auto' } = req.body;

  if (!text || !text.trim()) {
    return res.status(400).json({ error: 'No text provided' });
  }

  try {
    const { translate } = await import('@vitalets/google-translate-api');

    const result = await translate(text, { from, to: 'en' });

    // The raw response sometimes includes pronunciation/transliteration
    const romanized =
      result.raw?.pronunciation ||
      result.raw?.dict?.[0]?.terms?.[0] ||
      result.text;

    res.json({ romanized });
  } catch (err) {
    console.error('Romanize error:', err.message);
    res.status(500).json({ error: err.message || 'Romanization failed' });
  }
});

// Fallback to index.html
app.get('*', (req, res) => {
  res.sendFile(path.join(staticDir, 'index.html'));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () =>
  console.log(`LinguaFlow running → http://localhost:${PORT}`)
);
